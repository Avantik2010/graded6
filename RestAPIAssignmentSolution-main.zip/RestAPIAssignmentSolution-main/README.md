[RestAPIAssignment6Screenshot.pdf](https://github.com/JeyachithraBalaraman/RestAPIAssignmentSolution/files/9167771/RestAPIAssignment6Screenshot.pdf)
[Graded Project.docx](https://github.com/JeyachithraBalaraman/RestAPIAssignmentSolution/files/9167781/Graded.Project.docx)
# RestAPIAssignmentSolution
>> Have used data.sql to add users, roles
>> Used Postman to perform the other operations in Employee database
>> H2-Console is used as database
